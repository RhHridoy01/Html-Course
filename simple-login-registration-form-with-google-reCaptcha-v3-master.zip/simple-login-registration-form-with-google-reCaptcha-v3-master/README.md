# simple-login-registration-form with google reCaptcha v3

A login and registration form utilizing HTML, PHP, JavaScript, Bootstrap and MySQL. 
This structure permits the client to enlist and sign in. 
All the data is put away in MySQL database. Registrations are secured by reCaptcha v3 and keeping in mind that login if the client exists in the database it will send an OTP to the client email. After progress full login it prompts the landing page. 

Highlights 

expand on object-arranged programming procedure 

stores passwords in DB as hashes 

simple log out through logout.php 

intended for security
