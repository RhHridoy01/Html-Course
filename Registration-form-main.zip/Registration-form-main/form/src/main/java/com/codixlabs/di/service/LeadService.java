package com.codixlabs.di.service;

import com.codixlabs.di.model.Lead;

public interface LeadService {
	
	boolean saveLead(Lead lead);

}
